import 'package:flame/game.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:racing/features/providers/settings_provider.dart';
import 'package:racing/game/audio/audio_service.dart';
import 'package:racing/data/models/ai_profile.dart';
import 'package:racing/features/providers/progress_provider.dart';
import 'package:racing/data/tracks/track_library.dart';
import 'package:racing/game/overlays/hud_overlay.dart';
import 'package:racing/game/overlays/loading_view.dart';
import 'package:racing/game/overlays/pause_overlay.dart';
import 'package:racing/game/overlays/results_overlay.dart';
import 'package:racing/game/overlays/touch_controls_overlay.dart';
import 'package:racing/game/overlays/tuning_overlay.dart';
import 'package:racing/game/racing_game.dart';

class RaceScreen extends ConsumerStatefulWidget {
  const RaceScreen({
    required this.trackId,
    required this.carIndex,
    this.difficulty = AiDifficulty.medium,
    this.aiCount = 5,
    this.championship = false,
    super.key,
  });

  final String trackId;
  final int carIndex;
  final AiDifficulty difficulty;
  final int aiCount;
  final bool championship;

  @override
  ConsumerState<RaceScreen> createState() => _RaceScreenState();
}

class _RaceScreenState extends ConsumerState<RaceScreen>
    with WidgetsBindingObserver {
  late final RacingGame _game;
  bool _recorded = false;

  @override
  void initState() {
    super.initState();
    _game = RacingGame(
      trackData: TrackLibrary.byId(widget.trackId),
      carStats: ref.read(progressProvider.notifier).statsFor(widget.carIndex),
      difficulty: widget.difficulty,
      aiCount: widget.aiCount,
      audio: ref.read(audioServiceProvider),
      quality: ref.read(settingsProvider).graphicsQuality,
      haptics: ref.read(settingsProvider).haptics,
      controlScheme: ref.read(settingsProvider).controlScheme,
      steerSensitivity: ref.read(settingsProvider).steeringSensitivity,
    );
    WidgetsBinding.instance.addObserver(this);
    _game.result.addListener(_onResult);
  }

  /// Saves the race once, when the result first appears.
  void _onResult() {
    final r = _game.result.value;
    if (r == null) {
      _recorded = false;
      return;
    }
    if (_recorded) return;
    _recorded = true;
    ref.read(progressProvider.notifier).recordRace(
          r,
          championship: widget.championship,
        );
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _game.result.removeListener(_onResult);
    _game.audio.stopRaceAudio();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed &&
        !_game.overlays.isActive(RacingGame.pauseOverlay)) {
      _game.pauseGame();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GameWidget<RacingGame>(
        game: _game,
        loadingBuilder: (context) => LoadingView(progress: _game.loadProgress),
        errorBuilder: (context, error) =>
            Center(child: Text('Game error: $error')),
        overlayBuilderMap: {
          RacingGame.hudOverlay: (context, game) => HudOverlay(game: game),
          RacingGame.controlsOverlay: (context, game) =>
              TouchControlsOverlay(game: game),
          RacingGame.tuningOverlay: (context, game) =>
              TuningOverlay(game: game),
          RacingGame.pauseOverlay: (context, game) => PauseOverlay(game: game),
          RacingGame.resultsOverlay: (context, game) =>
              ResultsOverlay(game: game),
        },
        initialActiveOverlays: const [
          RacingGame.hudOverlay,
          RacingGame.controlsOverlay,
        ],
      ),
    );
  }
}
